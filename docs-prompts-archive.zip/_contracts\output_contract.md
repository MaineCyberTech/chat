Output contract prompt

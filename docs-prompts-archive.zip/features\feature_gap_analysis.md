Feature gap prompt

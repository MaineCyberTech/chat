Auto remediation prompt

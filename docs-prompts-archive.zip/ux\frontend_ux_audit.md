UX audit prompt

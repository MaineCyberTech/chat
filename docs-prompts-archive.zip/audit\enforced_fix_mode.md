FIX loop prompt placeholder

Master reconciliation process.

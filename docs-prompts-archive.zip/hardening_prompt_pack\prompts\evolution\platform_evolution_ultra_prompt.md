Platform evolution prompt.

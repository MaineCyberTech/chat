Data integrity prompt.

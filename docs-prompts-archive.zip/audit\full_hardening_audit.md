FULL audit prompt placeholder

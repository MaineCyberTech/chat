Release gate prompt

Principal security audit prompt.

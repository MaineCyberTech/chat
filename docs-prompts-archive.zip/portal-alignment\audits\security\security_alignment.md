Security audit: auth, tenancy.

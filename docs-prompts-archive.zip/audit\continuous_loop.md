Continuous loop prompt

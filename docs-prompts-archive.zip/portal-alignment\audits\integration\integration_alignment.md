Integration audit: cross-system.

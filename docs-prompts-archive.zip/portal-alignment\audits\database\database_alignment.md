Database audit: schema + migrations.

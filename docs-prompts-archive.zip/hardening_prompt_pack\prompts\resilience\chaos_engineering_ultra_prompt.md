Chaos engineering prompt.
